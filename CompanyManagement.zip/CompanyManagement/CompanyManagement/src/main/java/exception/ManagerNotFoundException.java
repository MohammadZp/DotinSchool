package exception;

public class ManagerNotFoundException extends Exception{
    public ManagerNotFoundException(String s){
        super(s);
    }
}
