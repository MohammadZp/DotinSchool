package exception;

public class EnableUserException extends Exception {
    public EnableUserException(Object disable) {
    }
}
