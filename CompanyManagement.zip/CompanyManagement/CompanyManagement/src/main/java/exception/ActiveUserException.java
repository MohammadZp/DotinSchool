package exception;

public class ActiveUserException extends Exception {
    public ActiveUserException(String s) {
    }
}
