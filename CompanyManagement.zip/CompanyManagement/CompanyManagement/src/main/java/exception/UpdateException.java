package exception;

public class UpdateException extends Throwable {
    public UpdateException(String updateExceptionMessage) {
    }
}
