package exception;

public class UpdateLeaveException extends Exception{
    public UpdateLeaveException(String updateExceptionMessage) {
    }
}
