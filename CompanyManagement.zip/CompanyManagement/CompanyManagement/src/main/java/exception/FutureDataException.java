package exception;

public class FutureDataException extends Exception {
    public FutureDataException(String leaveDateException) {
    }
}
